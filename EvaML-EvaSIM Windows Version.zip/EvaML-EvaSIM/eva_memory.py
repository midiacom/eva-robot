# equivale ao $ do software original do Eva
# é uma lista de resultados
var_dolar = []

# case flag
reg_case = 0

# memória ram do Eva (um dicionário chave/valor)
vars = {}

